export class CreateUserDto {
  readonly email: string;
  readonly photo: string;
}
